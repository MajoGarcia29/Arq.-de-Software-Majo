package edu.unisabana.pizzafactory.Fabricas;

import edu.unisabana.pizzafactory.model.*;

public class FabricaPizzaGruesa implements FabricaPizza {
    @Override
    public Amasador crearAmasador() {
        return new AmasadorPizzaGruesa();
    }
    @Override
    public Moldeador crearMoldeador() {
        return new MoldeadorPizzaGruesa();
    }
    @Override
    public Horneador crearHorneador() {
        return new HorneadorPizzaGruesa();
    }
}
